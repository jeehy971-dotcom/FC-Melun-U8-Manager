import React, { useState, useEffect } from 'react'
import { saveAs } from 'file-saver'

const STORAGE_KEY = 'fc_melun_u8_manager_v1'

const defaultPlayers = Array.from({ length: 12 }).map((_, i) => ({
  id: `p-${i+1}`,
  firstName: '',
  lastName: '',
  dob: '2017-01-01',
  position: 'Joueur',
  preferredFoot: 'Droit',
  number: i+1,
  notes: ''
}))

const sampleState = {
  teamName: 'FC Melun U8 Manager',
  players: defaultPlayers,
  matches: []
}

function uid(prefix='id'){ return `${prefix}-${Math.random().toString(36).slice(2,9)}` }

export default function App(){
  const [state, setState] = useState(sampleState)
  const [tab, setTab] = useState('players')
  const [playerForm, setPlayerForm] = useState(null)
  const [matchForm, setMatchForm] = useState({ date:'', time:'', opponent:'', place:'', type:'Amical' })
  const [selectedMatchId, setSelectedMatchId] = useState(null)

  useEffect(()=> {
    const raw = localStorage.getItem(STORAGE_KEY)
    if(raw){
      try{ setState(JSON.parse(raw)) } catch(e){ console.error('parse',e) }
    }
  },[])

  useEffect(()=> {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  },[state])

  // players
  function addPlayer(p){
    setState(s=>({...s, players: [...s.players, {...p, id: uid('p') }]}))
  }
  function updatePlayer(id, fields){
    setState(s=>({...s, players: s.players.map(p=> p.id===id ? {...p, ...fields} : p)}))
  }
  function removePlayer(id){
    setState(s=>({...s, players: s.players.filter(p=> p.id !== id)}))
  }

  // matches
  function addMatch(m){
    const match = {...m, id: uid('m'), attendees: {}, playerStats: {} }
    setState(s=>({...s, matches: [...s.matches, match]}))
  }
  function removeMatch(id){
    setState(s=>({...s, matches: s.matches.filter(m=> m.id !== id)}))
  }
  function toggleAttendance(matchId, playerId){
    setState(s=>{
      const matches = s.matches.map(m=>{
        if(m.id !== matchId) return m
        const attendees = {...m.attendees}
        attendees[playerId] = !attendees[playerId]
        const playerStats = {...(m.playerStats||{})}
        if(attendees[playerId]) playerStats[playerId] = playerStats[playerId] || { goals:0, assists:0 }
        return {...m, attendees, playerStats}
      })
      return {...s, matches}
    })
  }
  function updatePlayerStat(matchId, playerId, stat, value){
    setState(s=>{
      const matches = s.matches.map(m=>{
        if(m.id !== matchId) return m
        const playerStats = {...(m.playerStats||{})}
        playerStats[playerId] = {...(playerStats[playerId] || { goals:0, assists:0 }), [stat]: value}
        return {...m, playerStats}
      })
      return {...s, matches}
    })
  }

  function exportJSON(){ const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'}); saveAs(blob,'fc_melun_u8_manager_export.json') }
  function importJSON(file){
    const reader = new FileReader()
    reader.onload = (e)=> {
      try{ setState(JSON.parse(e.target.result)) } catch(err){ alert('Fichier JSON invalide') }
    }
    reader.readAsText(file)
  }

  // simple aggregates
  const aggregate = React.useMemo(()=>{
    const byPlayer = {}
    state.players.forEach(p=> byPlayer[p.id] = { ...p, matches:0, goals:0, assists:0 })
    state.matches.forEach(m=>{
      if(!m.attendees) return
      state.players.forEach(p=>{
        if(m.attendees[p.id]){
          byPlayer[p.id].matches += 1
          const s = (m.playerStats && m.playerStats[p.id]) || {}
          byPlayer[p.id].goals += Number(s.goals || 0)
          byPlayer[p.id].assists += Number(s.assists || 0)
        }
      })
    })
    return Object.values(byPlayer)
  }, [state])

  return (
    <div>
      <header className="header">
        <div>
          <strong>{state.teamName}</strong>
          <div className="small">Gestion présences & stats — simple</div>
        </div>
        <nav className="flex">
          <button className="btn" onClick={()=>setTab('players')}>Joueurs</button>
          <button className="btn" onClick={()=>setTab('matches')}>Matchs</button>
          <button className="btn" onClick={()=>setTab('settings')}>Paramètres</button>
        </nav>
      </header>

      <main className="container">
        {tab === 'players' && (
          <div>
            <div className="card">
              <h3>Ajouter / éditer un joueur</h3>
              <PlayerForm onAdd={(f)=>{ addPlayer(f); }} />
            </div>

            <div className="card">
              <h3>Liste des joueurs ({state.players.length})</h3>
              <table className="table">
                <thead>
                  <tr><th>#</th><th>Nom</th><th>Prés</th><th>Buts</th><th></th></tr>
                </thead>
                <tbody>
                  {state.players.map((p, idx)=> {
                    const agg = aggregate.find(a=> a.id === p.id) || {}
                    return (
                      <tr key={p.id}>
                        <td>{p.number}</td>
                        <td>{p.firstName} {p.lastName}</td>
                        <td>{agg.matches || 0}</td>
                        <td>{agg.goals || 0}</td>
                        <td>
                          <button className="small" onClick={()=> setPlayerForm(p)}>Éditer</button>
                          <button className="small" onClick={()=> removePlayer(p.id)}>Suppr</button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            {playerForm && (
              <div className="card">
                <h3>Éditer joueur</h3>
                <input className="input" value={playerForm.firstName} onChange={(e)=> setPlayerForm({...playerForm, firstName: e.target.value})} placeholder="Prénom" />
                <input className="input" value={playerForm.lastName} onChange={(e)=> setPlayerForm({...playerForm, lastName: e.target.value})} placeholder="Nom" />
                <div className="flex" style={{marginTop:8}}>
                  <button className="btn" onClick={()=> { updatePlayer(playerForm.id, playerForm); setPlayerForm(null) }}>Sauvegarder</button>
                  <button className="small" onClick={()=> setPlayerForm(null)}>Annuler</button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'matches' && (
          <div>
            <div className="card">
              <h3>Planifier un match</h3>
              <div style={{display:'grid',gap:8}}>
                <input type="date" className="input" value={matchForm.date} onChange={(e)=> setMatchForm({...matchForm, date: e.target.value})} />
                <input type="time" className="input" value={matchForm.time} onChange={(e)=> setMatchForm({...matchForm, time: e.target.value})} />
                <input className="input" placeholder="Adversaire" value={matchForm.opponent} onChange={(e)=> setMatchForm({...matchForm, opponent: e.target.value})} />
                <input className="input" placeholder="Lieu" value={matchForm.place} onChange={(e)=> setMatchForm({...matchForm, place: e.target.value})} />
                <select className="input" value={matchForm.type} onChange={(e)=> setMatchForm({...matchForm, type: e.target.value})}>
                  <option>Amical</option>
                  <option>Championnat</option>
                  <option>Tournoi</option>
                </select>
                <div className="flex">
                  <button className="btn" onClick={()=> { addMatch(matchForm); setMatchForm({ date:'', time:'', opponent:'', place:'', type:'Amical' }) }}>Ajouter</button>
                </div>
              </div>
            </div>

            <div className="card">
              <h3>Liste des matchs ({state.matches.length})</h3>
              <table className="table">
                <thead><tr><th>Date</th><th>Adversaire</th><th>Prés</th><th></th></tr></thead>
                <tbody>
                  {state.matches.map(m=>(
                    <tr key={m.id}>
                      <td>{m.date} {m.time}</td>
                      <td>{m.opponent}</td>
                      <td>{Object.values(m.attendees||{}).filter(Boolean).length}/{state.players.length}</td>
                      <td>
                        <button className="small" onClick={()=> { setSelectedMatchId(m.id); setTab('matchDetail') }}>Ouvrir</button>
                        <button className="small" onClick={()=> removeMatch(m.id)}>Suppr</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'matchDetail' && (
          <MatchDetail match={state.matches.find(m=> m.id === selectedMatchId)} players={state.players} toggleAttendance={toggleAttendance} updatePlayerStat={updatePlayerStat} goBack={()=>{ setTab('matches'); setSelectedMatchId(null) }} />
        )}

        {tab === 'settings' && (
          <div>
            <div className="card">
              <h3>Paramètres</h3>
              <div className="flex">
                <button className="btn" onClick={()=> { if(confirm('Réinitialiser toutes les données?')) { setState(sampleState) }}}>Réinitialiser</button>
                <button className="btn" onClick={exportJSON}>Exporter JSON</button>
                <label className="small" style={{padding:'6px 10px',border:'1px solid #ddd',borderRadius:6,display:'inline-block',cursor:'pointer'}}>
                  Importer JSON
                  <input type="file" accept="application/json" style={{display:'none'}} onChange={(e)=> e.target.files && importJSON(e.target.files[0])} />
                </label>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

function PlayerForm({onAdd}){
  const [form, setForm] = useState({ firstName:'', lastName:'', dob:'2017-01-01', position:'Joueur', preferredFoot:'Droit', number: '' })
  return (
    <div style={{display:'grid',gap:8}}>
      <input className="input" placeholder="Prénom" value={form.firstName} onChange={(e)=> setForm({...form, firstName: e.target.value})} />
      <input className="input" placeholder="Nom" value={form.lastName} onChange={(e)=> setForm({...form, lastName: e.target.value})} />
      <input className="input" placeholder="N° maillot" value={form.number} onChange={(e)=> setForm({...form, number: e.target.value})} />
      <div className="flex">
        <button className="btn" onClick={()=> { if(!form.firstName && !form.lastName){ alert('Remplis au moins un nom'); return } onAdd({...form, number: form.number || undefined}); setForm({ firstName:'', lastName:'', dob:'2017-01-01', position:'Joueur', preferredFoot:'Droit', number:'' }) }}>Ajouter</button>
      </div>
    </div>
  )
}

function MatchDetail({match, players, toggleAttendance, updatePlayerStat, goBack}){
  if(!match) return <div className="card">Match introuvable <button className="small" onClick={goBack}>Retour</button></div>
  return (
    <div>
      <div className="card">
        <h3>Match — {match.date} {match.time} — {match.opponent}</h3>
        <div className="flex">
          <button className="btn" onClick={goBack}>Retour</button>
        </div>
      </div>

      <div className="card">
        <h4>Présences</h4>
        <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:8}}>
          {players.map(p=>(
            <label key={p.id} className="card" style={{display:'flex',alignItems:'center',gap:8}}>
              <input type="checkbox" checked={!!(match.attendees && match.attendees[p.id])} onChange={()=> toggleAttendance(match.id, p.id)} />
              <div>
                <div><strong>{p.firstName} {p.lastName}</strong></div>
                <div className="small">#{p.number} — {p.position}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="card">
        <h4>Stats par joueur</h4>
        <div style={{display:'grid',gap:8}}>
          {players.map(p=>{
            const stats = (match.playerStats && match.playerStats[p.id]) || { goals:0, assists:0 }
            const attending = !!(match.attendees && match.attendees[p.id])
            return (
              <div key={p.id} className="card">
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <div><strong>{p.firstName} {p.lastName}</strong> {!attending && <span className="small" style={{color:'#c00'}}>Absent</span>}</div>
                </div>
                <div style={{display:'flex',gap:8,marginTop:8}}>
                  <div style={{width:80}}>
                    <label className="small">Buts</label>
                    <input className="input" type="number" min="0" value={stats.goals} onChange={(e)=> updatePlayerStat(match.id, p.id, 'goals', Number(e.target.value))} />
                  </div>
                  <div style={{width:120}}>
                    <label className="small">Passes</label>
                    <input className="input" type="number" min="0" value={stats.assists} onChange={(e)=> updatePlayerStat(match.id, p.id, 'assists', Number(e.target.value))} />
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
