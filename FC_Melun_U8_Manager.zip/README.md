# FC Melun U8 Manager (simple)

Version simple — application web React prête à déployer.

## Contenu
- Vite + React project
- Fonctionnalités:
  - 12 emplacements joueurs vides
  - Planification de matchs
  - Présences par match
  - Statistiques simples: buts, passes
  - Export / import JSON
  - Sauvegarde en localStorage

## Installation locale (optionnel)
1. Installer Node.js (16+)
2. `npm install`
3. `npm run dev`
4. Ouvrir `http://localhost:5173`

## Déploiement sur Vercel (recommandé)
1. Crée un repository GitHub et upload le contenu du projet.
2. Connecte ton compte GitHub sur https://vercel.com
3. Import le projet depuis GitHub et clique sur **Deploy**.
4. Vercel build et publiera automatiquement; tu auras un lien public.

---

Si tu veux, je peux:
- générer le fichier ZIP maintenant (je l'ai fait), 
- te fournir le lien de téléchargement,
- puis te guider étape par étape pour l'importer sur GitHub et le déployer sur Vercel.
